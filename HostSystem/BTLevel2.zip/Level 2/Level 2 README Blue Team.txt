
                        /\
                        ||
                        ||
                        ||
                        ||                                               ~-----~
                        ||                                            /===--  ---~~~
                        ||                   ;'                 /==~- --   -    ---~~~
                        ||                (/ ('              /=----         ~~_  --(  '
                        ||             ' / ;'             /=----               \__~
     '                ~==_=~          '('             ~-~~      ~~~~        ~~~--\~'
     \\                (c_\_        .i.             /~--    ~~~--   -~     (     '
      `\               (}| /       / : \           / ~~------~     ~~\   (
      \ '               ||/ \      |===|          /~/             ~~~ \ \(
      ``~\              ~~\  )~.~_ >._.< _~-~     |`_          ~~-~     )\
       '-~                 {  /  ) \___/ (   \   |` ` _       ~~         '
       \ -~\                -<__/  -   -  L~ -;   \\    \ _ _/
       `` ~~=\                  {    :    }\ ,\    ||   _ :(
        \  ~~=\__                \ _/ \_ /  )  } _//   ( `|'
        ``    , ~\--~=\           \     /  / _/ / '    (   '
         \`    } ~ ~~ -~=\   _~_  / \ / \ )^ ( // :_  / '
         |    ,          _~-'   '~~__-_  / - |/     \ (
          \  ,_--_     _/              \_'---', -~ .   \
           )/      /\ / /\   ,~,         \__ _}     \_  "~_
           ,      { ( _ )'} ~ - \_    ~\  (-:-)       "\   ~ 
                  /'' ''  )~ \~_ ~\   )->  \ :|    _,       " 
                 (\  _/)''} | \~_ ~  /~(   | :)   /          }
                <``  >;,,/  )= \~__ {{{ '  \ =(  ,   ,       ;
               {o_o }_/     |v  '~__  _    )-v|  "  :       ,"
               {/"\_)       {_/'  \~__ ~\_ \\_} '  {        /~\
               ,/!          '_/    '~__ _-~ \_' :  '      ,"  ~ 
              (''`                  /,'~___~    | /     ,"  \ ~' 
             '/, )                 (-)  '~____~";     ,"     , }
           /,')                    / \         /  ,~-"       '~'
       (  ''/                     / ( '       /  /          '~'
    ~ ~  ,, /) ,                 (/( \)      ( -)          /~'
  (  ~~ )`  ~}                   '  \)'     _/ /           ~'
 { |) /`,--.(  }'                    '     (  /          /~'
(` ~ ( c|~~| `}   )                        '/:\         ,'
 ~ )/``) )) '|),                          (/ | \)
  (` (-~(( `~`'  )                        ' (/ '
   `~'    )'`')                              '
     ` ``
                    (                                        (                    
  *   )    )         )\ )                            (        )\ )                 
` )  /( ( /(    (   (()/(   (       )  (  (          )\      (()/(     )  (   (    
 ( )(_)))\())  ))\   /(_))  )(   ( /(  )\))(  (    (((_) (    /(_)) ( /(  )\  )(   
(_(_())((_)\  /((_) (_))_  (()\  )(_))((_))\  )\   )\ )  )\  (_))   )(_))((_)(()\  
|_   _|| |(_)(_))    |   \  ((_)((_)_  (()(_)((_) _(_/( ((_) | |   ((_)_  (_) ((_) 
  | |  | ' \ / -_)   | |) || '_|/ _` |/ _` |/ _ \| ' \))(_-< | |__ / _` | | || '_| 
  |_|  |_||_|\___|   |___/ |_|  \__,_|\__, |\___/|_||_| /__/ |____|\__,_| |_||_|   
                                      |___/  
	Welcome to The Dragon’s Lair, a cybersecurity CTF game. Your team will be the Blue Team. There are six levels, in the format of Forensics, Forensics, Attack & Defend, Forensics, Attack & Defend, Attack & Defend. Forensics questions include solving clues and finding the flag within your own system, so intruding your opponent’s system is not necessary. Intrusion of an opponent’s system is legal in any and all levels. 100 points will be awarded for the completion of each level. Hints can be accessed by typing 'hint' in Terminal. 10 points will be deducted for each new hint you receive, and you will only be able to see each hint once. If you believe you may have found a bug or an error with the image or the competition, use the command 'customerservice'.

Penalties and possible disqualifications will occur for the following:
- Uninstalling OpenSSH-Server
- Uninstalling SSHpass
- Disabling UFW or any form of firewall
- Denying port 22
- Changing passwords of accounts on either system
- Using SSH to access the host system
- Using Mac applications
- Communication between teams on non-competition systems (e.g. phones, personal laptops, etc)
- Using services other than OpenSSH to remotely access other systems
- Disabling remote access between any system to the host system
- Modifying or deleting scripts found in the 'The Dragon's Lair' folder on either system

Level 2:
	After a week of sleepless nights, I was finally able to extract the password for the main account on Red Team's system. I would just give it to you, but that wouldn't be any fun. I decided to encode the password multiple times. Here is the encrypted password: "34333739363233333732333533333433". If that's too difficult for you, look at the clue file in the Level 2 folder. The decrypted password will not only be the password to Red Team's system but also the key for this level. Good luck!

~ Il Drago