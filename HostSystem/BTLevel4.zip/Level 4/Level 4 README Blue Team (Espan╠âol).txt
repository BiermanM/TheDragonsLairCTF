
                        /\
                        ||
                        ||
                        ||
                        ||                                               ~-----~
                        ||                                            /===--  ---~~~
                        ||                   ;'                 /==~- --   -    ---~~~
                        ||                (/ ('              /=----         ~~_  --(  '
                        ||             ' / ;'             /=----               \__~
     '                ~==_=~          '('             ~-~~      ~~~~        ~~~--\~'
     \\                (c_\_        .i.             /~--    ~~~--   -~     (     '
      `\               (}| /       / : \           / ~~------~     ~~\   (
      \ '               ||/ \      |===|          /~/             ~~~ \ \(
      ``~\              ~~\  )~.~_ >._.< _~-~     |`_          ~~-~     )\
       '-~                 {  /  ) \___/ (   \   |` ` _       ~~         '
       \ -~\                -<__/  -   -  L~ -;   \\    \ _ _/
       `` ~~=\                  {    :    }\ ,\    ||   _ :(
        \  ~~=\__                \ _/ \_ /  )  } _//   ( `|'
        ``    , ~\--~=\           \     /  / _/ / '    (   '
         \`    } ~ ~~ -~=\   _~_  / \ / \ )^ ( // :_  / '
         |    ,          _~-'   '~~__-_  / - |/     \ (
          \  ,_--_     _/              \_'---', -~ .   \
           )/      /\ / /\   ,~,         \__ _}     \_  "~_
           ,      { ( _ )'} ~ - \_    ~\  (-:-)       "\   ~ 
                  /'' ''  )~ \~_ ~\   )->  \ :|    _,       " 
                 (\  _/)''} | \~_ ~  /~(   | :)   /          }
                <``  >;,,/  )= \~__ {{{ '  \ =(  ,   ,       ;
               {o_o }_/     |v  '~__  _    )-v|  "  :       ,"
               {/"\_)       {_/'  \~__ ~\_ \\_} '  {        /~\
               ,/!          '_/    '~__ _-~ \_' :  '      ,"  ~ 
              (''`                  /,'~___~    | /     ,"  \ ~' 
             '/, )                 (-)  '~____~";     ,"     , }
           /,')                    / \         /  ,~-"       '~'
       (  ''/                     / ( '       /  /          '~'
    ~ ~  ,, /) ,                 (/( \)      ( -)          /~'
  (  ~~ )`  ~}                   '  \)'     _/ /           ~'
 { |) /`,--.(  }'                    '     (  /          /~'
(` ~ ( c|~~| `}   )                        '/:\         ,'
 ~ )/``) )) '|),                          (/ | \)
  (` (-~(( `~`'  )                        ' (/ '
   `~'    )'`')                              '
     ` ``
                    (                                        (                    
  *   )    )         )\ )                            (        )\ )                 
` )  /( ( /(    (   (()/(   (       )  (  (          )\      (()/(     )  (   (    
 ( )(_)))\())  ))\   /(_))  )(   ( /(  )\))(  (    (((_) (    /(_)) ( /(  )\  )(   
(_(_())((_)\  /((_) (_))_  (()\  )(_))((_))\  )\   )\ )  )\  (_))   )(_))((_)(()\  
|_   _|| |(_)(_))    |   \  ((_)((_)_  (()(_)((_) _(_/( ((_) | |   ((_)_  (_) ((_) 
  | |  | ' \ / -_)   | |) || '_|/ _` |/ _` |/ _ \| ' \))(_-< | |__ / _` | | || '_| 
  |_|  |_||_|\___|   |___/ |_|  \__,_|\__, |\___/|_||_| /__/ |____|\__,_| |_||_|   
                                      |___/  
	Bienvenido a la guarida del dragón, un juego CTF ciberseguridad. El equipo va a ser el equipo azul. Hay seis niveles, en el formato de análisis forense, medicina forense, Ataque y Defensa, Medicina Forense, Ataque y Defensa, Ataque y Defensa. Medicina forense preguntas incluyen resolviendo pistas y encontrar la bandera dentro de su propio sistema, por lo que entrometerse sistema de su oponente no es necesario. Intrusión del sistema de un oponente es legal en cualquier y todos los niveles. 100 puntos serán otorgados para la terminación de cada nivel. Consejos se puede acceder tecleando 'hint' en la Terminal. 10 puntos serán deducidos para cada nueva pista que recibe, y sólo se podrán ver cada pista una vez. Si usted cree que puede haber encontrado un fallo o un error en la imagen o la competición, utilice el comando 'customerservice'.

Las sanciones y las posibles descalificaciones ocurrirán durante el siguiente:
- La desinstalación de OpenSSH-Server
- La desinstalación SSHpass
- Desactivación UFW o cualquier forma de cortafuegos
- Negar el puerto 22
- Cambio de contraseñas de cuentas en cualquiera de los sistemas
- Uso de SSH para acceder al sistema host
- Utilización de las aplicaciones de Mac
- La comunicación entre los equipos en sistemas que no son de competencia (por ejemplo, los teléfonos portátiles personales, etc.)
- El uso de servicios distintos de OpenSSH para acceder de forma remota otros sistemas
- Deshabilitar el acceso a distancia entre cualquier sistema para el sistema host
- Modificación o eliminación de secuencias de comandos que se encuentran en la carpeta 'The Dragon's Lair' en cualquiera de los sistemas

Nivel 4:
	Bienvenido a Nivel 4! Este nivel forense tiene varias partes, y por lo tanto múltiples banderas. Todas las banderas están relacionados, por lo que una bandera dará lugar a otro.
	
~ Il Drago