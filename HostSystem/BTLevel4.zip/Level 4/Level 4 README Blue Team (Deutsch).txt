
                        /\
                        ||
                        ||
                        ||
                        ||                                               ~-----~
                        ||                                            /===--  ---~~~
                        ||                   ;'                 /==~- --   -    ---~~~
                        ||                (/ ('              /=----         ~~_  --(  '
                        ||             ' / ;'             /=----               \__~
     '                ~==_=~          '('             ~-~~      ~~~~        ~~~--\~'
     \\                (c_\_        .i.             /~--    ~~~--   -~     (     '
      `\               (}| /       / : \           / ~~------~     ~~\   (
      \ '               ||/ \      |===|          /~/             ~~~ \ \(
      ``~\              ~~\  )~.~_ >._.< _~-~     |`_          ~~-~     )\
       '-~                 {  /  ) \___/ (   \   |` ` _       ~~         '
       \ -~\                -<__/  -   -  L~ -;   \\    \ _ _/
       `` ~~=\                  {    :    }\ ,\    ||   _ :(
        \  ~~=\__                \ _/ \_ /  )  } _//   ( `|'
        ``    , ~\--~=\           \     /  / _/ / '    (   '
         \`    } ~ ~~ -~=\   _~_  / \ / \ )^ ( // :_  / '
         |    ,          _~-'   '~~__-_  / - |/     \ (
          \  ,_--_     _/              \_'---', -~ .   \
           )/      /\ / /\   ,~,         \__ _}     \_  "~_
           ,      { ( _ )'} ~ - \_    ~\  (-:-)       "\   ~ 
                  /'' ''  )~ \~_ ~\   )->  \ :|    _,       " 
                 (\  _/)''} | \~_ ~  /~(   | :)   /          }
                <``  >;,,/  )= \~__ {{{ '  \ =(  ,   ,       ;
               {o_o }_/     |v  '~__  _    )-v|  "  :       ,"
               {/"\_)       {_/'  \~__ ~\_ \\_} '  {        /~\
               ,/!          '_/    '~__ _-~ \_' :  '      ,"  ~ 
              (''`                  /,'~___~    | /     ,"  \ ~' 
             '/, )                 (-)  '~____~";     ,"     , }
           /,')                    / \         /  ,~-"       '~'
       (  ''/                     / ( '       /  /          '~'
    ~ ~  ,, /) ,                 (/( \)      ( -)          /~'
  (  ~~ )`  ~}                   '  \)'     _/ /           ~'
 { |) /`,--.(  }'                    '     (  /          /~'
(` ~ ( c|~~| `}   )                        '/:\         ,'
 ~ )/``) )) '|),                          (/ | \)
  (` (-~(( `~`'  )                        ' (/ '
   `~'    )'`')                              '
     ` ``
                    (                                        (                    
  *   )    )         )\ )                            (        )\ )                 
` )  /( ( /(    (   (()/(   (       )  (  (          )\      (()/(     )  (   (    
 ( )(_)))\())  ))\   /(_))  )(   ( /(  )\))(  (    (((_) (    /(_)) ( /(  )\  )(   
(_(_())((_)\  /((_) (_))_  (()\  )(_))((_))\  )\   )\ )  )\  (_))   )(_))((_)(()\  
|_   _|| |(_)(_))    |   \  ((_)((_)_  (()(_)((_) _(_/( ((_) | |   ((_)_  (_) ((_) 
  | |  | ' \ / -_)   | |) || '_|/ _` |/ _` |/ _ \| ' \))(_-< | |__ / _` | | || '_| 
  |_|  |_||_|\___|   |___/ |_|  \__,_|\__, |\___/|_||_| /__/ |____|\__,_| |_||_|   
                                      |___/  
	Willkommen in der Drachenhöhle , ein Cyber-CTF-Spiel. Ihr Team wird das Blue Team sein. Es gibt sechs Ebenen, im Format von Forensik, Kriminalistik, Angriff & Verteidigung, Forensik, Angriff & Verteidigung, Angriff & Verteidigung. Forensics Fragen sind zu lösen Hinweise und die Flagge in Ihrem eigenen System zu finden, so gegnerischen System eindringende ist nicht erforderlich. Eindringen eines Systems des Gegners ist legal in jedem und allen Ebenen. 100 Punkte für den Abschluss jeder Ebene vergeben werden. Hinweise können durch Eingabe von 'hint' im Terminal zugegriffen werden. Das erste flagge ist 'farbband'. 10 Punkte werden für jeden neuen Hinweis erhalten Sie abgezogen werden, und Sie werden nur in der Lage sein, jeden Hinweis einmal zu sehen. Wenn Sie glauben, können Sie mit dem Bild einen Fehler oder einen Fehler gefunden haben oder den Wettbewerb, verwenden Sie den Befehl 'customerservice'.

Sanktionen und mögliche Disqualifikationen werden für die folgenden auftreten:
- Deinstallieren von OpenSSH-Server
- Deinstallieren von SSHpass
- Deaktivieren der UFW oder jede Form von Firewall
- Verweigern Port 22
- Ändern von Passwörtern von Konten auf beiden Systemen
- SSH Mit dem Host-System zugreifen
- Verwenden von Mac-Anwendungen
- Die Kommunikation zwischen Teams auf Nicht-Konkurrenz-Systemen (zum Beispiel Telefone, persönliche Laptops, etc.)
- Andere Dienste als OpenSSH Mit remote auf andere Systeme zugreifen
- Deaktivieren der Fernzugriff zwischen jedem System zum Hostsystem 
- Ändern oder Löschen von Skripten in der 'The Dragon's Lair' Ordner auf beiden Systemen gefunden

Stufe 4:
	Willkommen in der Stufe 4! Diese Forensik Ebene hat mehrere Teile, und somit mehrere Fahnen. Alle die Fahnen miteinander verbunden sind, so wird ein Flag zum anderen führen.

~ Il Drago
