
                        /\
                        ||
                        ||
                        ||
                        ||                                               ~-----~
                        ||                                            /===--  ---~~~
                        ||                   ;'                 /==~- --   -    ---~~~
                        ||                (/ ('              /=----         ~~_  --(  '
                        ||             ' / ;'             /=----               \__~
     '                ~==_=~          '('             ~-~~      ~~~~        ~~~--\~'
     \\                (c_\_        .i.             /~--    ~~~--   -~     (     '
      `\               (}| /       / : \           / ~~------~     ~~\   (
      \ '               ||/ \      |===|          /~/             ~~~ \ \(
      ``~\              ~~\  )~.~_ >._.< _~-~     |`_          ~~-~     )\
       '-~                 {  /  ) \___/ (   \   |` ` _       ~~         '
       \ -~\                -<__/  -   -  L~ -;   \\    \ _ _/
       `` ~~=\                  {    :    }\ ,\    ||   _ :(
        \  ~~=\__                \ _/ \_ /  )  } _//   ( `|'
        ``    , ~\--~=\           \     /  / _/ / '    (   '
         \`    } ~ ~~ -~=\   _~_  / \ / \ )^ ( // :_  / '
         |    ,          _~-'   '~~__-_  / - |/     \ (
          \  ,_--_     _/              \_'---', -~ .   \
           )/      /\ / /\   ,~,         \__ _}     \_  "~_
           ,      { ( _ )'} ~ - \_    ~\  (-:-)       "\   ~ 
                  /'' ''  )~ \~_ ~\   )->  \ :|    _,       " 
                 (\  _/)''} | \~_ ~  /~(   | :)   /          }
                <``  >;,,/  )= \~__ {{{ '  \ =(  ,   ,       ;
               {o_o }_/     |v  '~__  _    )-v|  "  :       ,"
               {/"\_)       {_/'  \~__ ~\_ \\_} '  {        /~\
               ,/!          '_/    '~__ _-~ \_' :  '      ,"  ~ 
              (''`                  /,'~___~    | /     ,"  \ ~' 
             '/, )                 (-)  '~____~";     ,"     , }
           /,')                    / \         /  ,~-"       '~'
       (  ''/                     / ( '       /  /          '~'
    ~ ~  ,, /) ,                 (/( \)      ( -)          /~'
  (  ~~ )`  ~}                   '  \)'     _/ /           ~'
 { |) /`,--.(  }'                    '     (  /          /~'
(` ~ ( c|~~| `}   )                        '/:\         ,'
 ~ )/``) )) '|),                          (/ | \)
  (` (-~(( `~`'  )                        ' (/ '
   `~'    )'`')                              '
     ` ``
                    (                                        (                    
  *   )    )         )\ )                            (        )\ )                 
` )  /( ( /(    (   (()/(   (       )  (  (          )\      (()/(     )  (   (    
 ( )(_)))\())  ))\   /(_))  )(   ( /(  )\))(  (    (((_) (    /(_)) ( /(  )\  )(   
(_(_())((_)\  /((_) (_))_  (()\  )(_))((_))\  )\   )\ )  )\  (_))   )(_))((_)(()\  
|_   _|| |(_)(_))    |   \  ((_)((_)_  (()(_)((_) _(_/( ((_) | |   ((_)_  (_) ((_) 
  | |  | ' \ / -_)   | |) || '_|/ _` |/ _` |/ _ \| ' \))(_-< | |__ / _` | | || '_| 
  |_|  |_||_|\___|   |___/ |_|  \__,_|\__, |\___/|_||_| /__/ |____|\__,_| |_||_|   
                                      |___/  
	Welcome to The Dragon’s Lair, a cybersecurity CTF game. Your team will be the Blue Team. There are six levels, in the format of Forensics, Forensics, Attack & Defend, Forensics, Attack & Defend, Attack & Defend. Forensics questions include solving clues and finding the flag within your own system, so intruding your opponent’s system is not necessary. Intrusion of an opponent’s system is legal in any and all levels. 100 points will be awarded for the completion of each level. Hints can be accessed by typing 'hint' in Terminal. 10 points will be deducted for each new hint you receive, and you will only be able to see each hint once. If you believe you may have found a bug or an error with the image or the competition, use the command 'customerservice'.

Penalties and possible disqualifications will occur for the following:
- Uninstalling OpenSSH-Server
- Uninstalling SSHpass
- Disabling UFW or any form of firewall
- Denying port 22
- Changing passwords of accounts on either system
- Using SSH to access the host system
- Using Mac applications
- Communication between teams on non-competition systems (e.g. phones, personal laptops, etc)
- Using services other than OpenSSH to remotely access other systems
- Disabling remote access between any system to the host system
- Modifying or deleting scripts found in the 'The Dragon's Lair' folder on either system

Level 5:
	You are given the file HIDEME.txt in the Level 5 folder. You must hide this file anywhere in your system. You may change the filename and file extension of the file, but you may NOT change the contents of the file. Doing so will result in an automatic loss of the round. You also need to access Red Team's system and find a file containing the password for the twenty encrypted files in your Level 5 folder. You can use the preinstalled mCrypt package/service to decrypt the files. The file on Red Team's system does not have any specific name or extension. Find the key in one of the ASCII art files to proceed to the next level.
	
~ Il Drago